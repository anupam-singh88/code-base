<?php
// database connection code

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;


if(isset($_POST['regId']))
{
// $con = mysqli_connect('localhost', 'database_user', 'database_password','database');
$con = mysqli_connect('localhost', 'rotarycl_reg-form', 'Temp@2022','rotarycl_regform');

// get the post records
$regId = $_POST['regId'];
$txtName = $_POST['txtName'];
$txtEmail = $_POST['txtEmail'];
$txtDob = $_POST['txtDob'];
$txtPhone = $_POST['txtPhone'];
$txtAddress = $_POST['txtAddress'];
$txtSchoolName = $_POST['txtSchoolName'];
$txtAge = $_POST['txtAge'];
$txtAgeGroup = $_POST['txtAgeGroup'];
// $txtMessage = $_POST['txtMessage'];
// database insert SQL code
$sql = "INSERT INTO `tbl_contact` (`Id`,`RegistrationNo`, `Name`, `Email`,`Dob`, `Phone`, `Address`,`SchoolName`,`Age`,`AgeGroup`) VALUES ('0','$regId', '$txtName', '$txtEmail','$txtDob','$txtPhone', '$txtAddress', '$txtSchoolName','$txtAge','$txtAgeGroup')";

// insert in database 
$rs = mysqli_query($con, $sql);


 //for sending email


require 'PHPMailer-master/src/Exception.php';
require 'PHPMailer-master/src/PHPMailer.php';
require 'PHPMailer-master/src/SMTP.php';

$mail = new PHPMailer();



// Settings
$mail->IsSMTP();
$mail->Mailer = "smtp";
$mail->CharSet = 'UTF-8';

$mail->Host       = "smtp.gmail.com";    // SMTP server example
$mail->SMTPDebug  = 0;                     // enables SMTP debug information (for testing)

$mail->SMTPAuth   = true;                  // enable SMTP authentication
$mail->SMTPSecure = "tls";
$mail->Port       = 587;                    // set the SMTP port for the GMAIL server
$mail->Username   = "anupamwelkin@gmail.com";            // SMTP account username example
$mail->Password   = "fcsmfyozriosyfuk";            // SMTP account password example

// Content
$mail->isHTML(true);                       // Set email format to HTML
$mail->AddAddress($txtEmail, $txtName);
$mail->SetFrom("anupamwelkin@gmail.com", "Anupam Singh");
$mail->Subject = 'New Registration';
//$mail->Body    = 'This is the HTML message body <b>in bold!</b>';
//$mail->AltBody = 'This is the body in plain text for non-HTML mail clients';
$content = "<b>Thankyou for registering with us for painting competition. This is your registration id - " . $regId . " </b>";

$mail->send();

$mail->MsgHTML($content); 

if(!$mail->Send()) {
  echo "Error while sending Email.";
  //var_dump($mail);
} else {
  echo "<p>&nbsp;</p><center><h2>Email sent successfully</h2>";
}


//$to = $txtEmail;

//$subject = "New Registration";

//$txt ="Registration ID = ". $regId . "\r\n Name = ". $txtName . "\r\n Phone = //" . $txtPhone . "\r\n  Email = " . $txtEmail . "\r\n Age =" . $txtAge;

//$headers = "From: " . $txtEmail. "\r\n" .

//"CC: nitin.gupta@welkinring.com";

//if($txtEmail!=NULL){

//    mail($to,$subject,$txt,$headers);

//}

//redirect

//header("Location:thankyou.html");

if($rs)
{
	// echo "Contact Records Inserted";
	echo '<div style="text-align:center;font-family:Arial;font-size:16px;width:50%;margin-left:25%;margin-right:25%;margin-top:5%;">';
	echo '<p>Registration No: ' . $_POST ["regId"] .'</p>';
	echo '<p>Name: ' . $_POST ["txtName"] . '</p>';
	echo '<p>Email: ' . $_POST ["txtEmail"] . '</p>';
	echo '<p>DOB: ' . $_POST ["txtDob"] . '</p>';
	echo '<p>Phone No: ' . $_POST ["txtPhone"].'</p>';
	echo '<p>Address: ' . $_POST ["txtAddress"].'</p>';
	echo '<p>School Name: ' . $_POST ["txtSchoolName"].'</p>';
	echo '<p>Age: ' . $_POST ["txtAge"].'</p>';
	echo '<p>Age Group: ' . $_POST ["txtAgeGroup"].'</p>';
	echo '</div>';
 ?>
	
<script type="text/javascript">
// 	setTimeout(() => {
		
// 		window.location = "https://rotaryclubdelhisouthwest.org/rotary-painting-competition-2023/reg-form.html";
// 	 }, 5000);


</script>      
    <?php
    
    
   
}
}
else
{
	echo "Are you a genuine visitor?";
	
}
?>
<button onclick="window.print()">Print this page</button>
